# Private shared board

The Site keeps its existing project identity and owner-only access policy. Root HTML is served by a protected route; API access requires the platform-authenticated user. Each identity maps to a generated internal principal ID. A different authenticated identity cannot read or replace the owner's boards.

D1 stores one versioned snapshot per principal and date. This deliberately saves editor assignments, suite modes and jobs atomically. Conditional revision updates reject stale writes; mutation IDs make retries safe after a lost response. Schema changes belong to generated Drizzle migrations, never request-time DDL.

The browser checks for changes every ten seconds while the page is visible and the user is not editing a form. It locks editing while loading or saving. Failures preserve a temporary browser draft and expose retry and conflict recovery controls. A full reload checks for an unsaved draft before allowing further edits.

## Legacy browser records

The board removes old date-based `edit1-shift-board:YYYY-MM-DD` records from browser storage whenever the updated site opens on a device. It does not remove shared D1 records, temporary unsaved-change drafts, or device display preferences.

Display settings stay device-local. Microsoft authentication is not implemented; confirm current platform support and organisational authorisation before adding it. Provider identities are separated from board ownership to permit a later explicit account mapping.

## Verification

`node --test tests/board-api.test.mjs` covers missing authentication, principal isolation, initial creation, stale updates, retry idempotency and cross-origin write rejection with the generated schema in SQLite.

Run the Sites build helper before publication. Production migration and device-to-device verification happen only after the database-enabled version is published. Never revert to the browser-only frontend after cloud writes without a deliberate data recovery plan.
