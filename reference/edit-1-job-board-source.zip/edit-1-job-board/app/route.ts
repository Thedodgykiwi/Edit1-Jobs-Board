import html from "../board/index.html?raw";
import { getChatGPTUser } from "./chatgpt-auth";
export const dynamic = "force-dynamic";
export async function GET() {
  if (!await getChatGPTUser()) return new Response(null, { status: 302, headers: { Location: "/signin-with-chatgpt?return_to=%2F" } });
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
}
