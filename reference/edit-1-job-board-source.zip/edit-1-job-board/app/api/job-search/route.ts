import { getChatGPTUser } from '../../chatgpt-auth';
import { database, ownerFor } from '../../../db/board-store';
import { searchSql, editorOptionsPageSql, collectEditorSuiteOptions, type EditorSuiteOption } from '../../../db/job-search';

export const dynamic = 'force-dynamic';
const reply = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });

export async function GET(request: Request) {
  try {
    const user = await getChatGPTUser();
    if (!user) return reply({ error: 'Sign in to search job history.' }, 401);
    const params = new URL(request.url).searchParams;
    const query = (params.get('q') || '').trim();
    const editor = (params.get('editor') || '').trim();
    const suite = Number(params.get('suite') || 0);
    const offset = Number(params.get('offset') || 0);
    if (query.length > 200 || editor.length > 200 || !Number.isInteger(suite) || suite < 0 || suite > 11 || !Number.isSafeInteger(offset) || offset < 0) {
      return reply({ error: 'Invalid search filters.' }, 400);
    }
    const owner = await ownerFor(user.userId);
    const db = database();
    if (params.get('facets') === '1') {
      const options = new Map<string, EditorSuiteOption>();
      let afterDate = "";
      while (true) {
        const page = await db.prepare(editorOptionsPageSql).bind(owner, afterDate).all<{ date: string; payload: string }>();
        for (const row of page.results) collectEditorSuiteOptions(JSON.parse(row.payload), options);
        if (page.results.length < 5) break;
        afterDate = page.results[page.results.length - 1].date;
      }
      const editors = [...options.values()].map(({ key, name, suites }) => ({ key, name, suites: [...suites].sort((a, b) => a - b) })).sort((a, b) => a.name.localeCompare(b.name, "en", { sensitivity: "base" }));
      return reply({ editors });
    }
    const pageSize = 40;
    const rows = await db.prepare(searchSql).bind(owner, query, editor, suite, pageSize + 1, offset)
      .all<{ date: string; job_json: string; editors_json: string }>();
    const results = rows.results.slice(0, pageSize).map((row) => ({
      date: row.date,
      job: JSON.parse(row.job_json),
      editors: JSON.parse(row.editors_json || '[]'),
    }));
    return reply({ results, hasMore: rows.results.length > pageSize, nextOffset: offset + results.length });
  } catch (error) {
    console.error('Job history search failed', error instanceof Error ? error.message : String(error));
    return reply({ error: 'Could not search job history. Please retry.' }, 503);
  }
}
