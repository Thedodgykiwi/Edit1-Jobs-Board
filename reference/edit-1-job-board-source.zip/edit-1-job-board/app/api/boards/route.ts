import { getChatGPTUser } from "../../chatgpt-auth";
import { database, ownerFor } from "../../../db/board-store";

export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store" };
const reply = (data: unknown, status = 200) => Response.json(data, { status, headers });
const validDate = (value: unknown): value is string => typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
type EditorPayload = { id: unknown; name: unknown; initials: unknown };
type JobPayload = { id: unknown; title: unknown; status: unknown };
type BoardPayload = { date: unknown; editors: EditorPayload[]; jobs: JobPayload[]; suites: Record<string, unknown>; suiteModes: Record<string, unknown> };

function validBoard(value: unknown): value is BoardPayload {
  if (!value || typeof value !== "object") return false;
  const board = value as Partial<BoardPayload>;
  return validDate(board.date)
    && Array.isArray(board.editors)
    && Array.isArray(board.jobs)
    && Boolean(board.suites && typeof board.suites === "object")
    && Boolean(board.suiteModes && typeof board.suiteModes === "object")
    && board.editors.every((editor) => editor && typeof editor.id === "string" && typeof editor.name === "string" && typeof editor.initials === "string")
    && board.jobs.every((job) => job && typeof job.id === "string" && typeof job.title === "string" && ["planned", "parked", "queued", "active", "completed", "biffed"].includes(String(job.status)));
}

export async function GET(request: Request) {
  try {
    const user = await getChatGPTUser();
    if (!user) return reply({ error: "Sign in to load your board." }, 401);
    const date = new URL(request.url).searchParams.get("date");
    if (!validDate(date)) return reply({ error: "Invalid board date." }, 400);
    const owner = await ownerFor(user.userId);
    if (new URL(request.url).searchParams.get("view") === "revision") {
      const row = await database().prepare("SELECT revision FROM boards WHERE owner_id = ? AND date = ?").bind(owner, date).first<{ revision: number }>();
      return reply({ revision: row?.revision ?? 0 });
    }
    const row = await database().prepare("SELECT payload, revision, mutation_id FROM boards WHERE owner_id = ? AND date = ?").bind(owner, date).first<{ payload: string; revision: number; mutation_id: string }>();
    return reply({ board: row ? JSON.parse(row.payload) : null, revision: row?.revision ?? 0, mutationId: row?.mutation_id ?? null });
  } catch (error) {
    console.error("Board load failed", error);
    return reply({ error: "Shared storage is unavailable. Please retry." }, 503);
  }
}

export async function PUT(request: Request) {
  try {
    const user = await getChatGPTUser();
    if (!user) return reply({ error: "Sign in to save your board." }, 401);
    if (request.headers.get("origin") !== new URL(request.url).origin || !request.headers.get("content-type")?.startsWith("application/json")) return reply({ error: "Invalid request origin." }, 403);
    const raw = await request.text();
    if (raw.length > 2000000) return reply({ error: "Board is too large." }, 413);
    let input;
    try { input = JSON.parse(raw); } catch { return reply({ error: "Invalid JSON." }, 400); }
    const { board, revision, mutationId } = input;
    if (!validBoard(board) || !Number.isSafeInteger(revision) || revision < 0 || typeof mutationId !== "string" || mutationId.length > 100) return reply({ error: "Invalid board." }, 400);
    const owner = await ownerFor(user.userId);
    const db = database();
    // Compare-and-swap keeps a stale device from overwriting a newer board.
    const result = revision === 0
      ? await db.prepare("INSERT INTO boards (owner_id, date, payload, revision, mutation_id, updated_at) VALUES (?, ?, ?, 1, ?, ?) ON CONFLICT(owner_id, date) DO NOTHING").bind(owner, board.date, JSON.stringify(board), mutationId, new Date().toISOString()).run()
      : await db.prepare("UPDATE boards SET payload = ?, revision = revision + 1, mutation_id = ?, updated_at = ? WHERE owner_id = ? AND date = ? AND revision = ?").bind(JSON.stringify(board), mutationId, new Date().toISOString(), owner, board.date, revision).run();
    if (result.meta.changes) return reply({ revision: revision + 1 });
    const current = await db.prepare("SELECT revision, mutation_id FROM boards WHERE owner_id = ? AND date = ?").bind(owner, board.date).first<{ revision: number; mutation_id: string }>();
    if (current?.mutation_id === mutationId) return reply({ revision: current.revision });
    return reply({ error: "Another device changed this board. Your unsaved copy has been kept; reload the shared version before editing again." }, 409);
  } catch (error) {
    console.error("Board save failed", error);
    return reply({ error: "Could not save. Your changes are still on this device; retry before closing." }, 503);
  }
}
