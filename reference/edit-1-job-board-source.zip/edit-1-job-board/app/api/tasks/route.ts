import { getChatGPTUser } from "../../chatgpt-auth";
import { database, ownerFor } from "../../../db/board-store";

export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store" };
const reply = (data: unknown, status = 200) => Response.json(data, { status, headers });

type TaskPayload = {
  id: unknown;
  title: unknown;
  note: unknown;
  starred?: unknown;
  isNote?: unknown;
  date?: unknown;
  reminderTime?: unknown;
  reminderAcknowledgedAt?: unknown;
  createdAt: unknown;
  completedAt: unknown;
};

function validDateKey(value: unknown) {
  if (typeof value !== "string") return false;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  return date.toISOString().slice(0, 10) === value;
}

function validTasks(value: unknown): value is TaskPayload[] {
  return Array.isArray(value)
    && value.length <= 5000
    && value.every((task) => task
      && typeof task.id === "string"
      && task.id.length <= 100
      && typeof task.title === "string"
      && task.title.trim().length > 0
      && task.title.length <= 120
      && typeof task.note === "string"
      && task.note.length <= 600
      && (task.starred === undefined || typeof task.starred === "boolean")
      && (task.isNote === undefined || typeof task.isNote === "boolean")
      && (task.isNote !== true || (task.completedAt === null && !task.reminderTime))
      && (task.date === undefined || validDateKey(task.date))
      && (task.reminderTime === undefined || task.reminderTime === null || (typeof task.reminderTime === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(task.reminderTime)))
      && (task.reminderAcknowledgedAt === undefined || task.reminderAcknowledgedAt === null || (typeof task.reminderAcknowledgedAt === "string" && !Number.isNaN(Date.parse(task.reminderAcknowledgedAt))))
      && typeof task.createdAt === "string"
      && !Number.isNaN(Date.parse(task.createdAt))
      && (task.completedAt === null || (typeof task.completedAt === "string" && !Number.isNaN(Date.parse(task.completedAt)))));
}

export async function GET(request: Request) {
  try {
    const user = await getChatGPTUser();
    if (!user) return reply({ error: "Sign in to load your checklist." }, 401);
    const owner = await ownerFor(user.userId);
    if (new URL(request.url).searchParams.get("view") === "revision") {
      const row = await database().prepare("SELECT revision FROM supervisor_task_lists WHERE owner_id = ?").bind(owner).first<{ revision: number }>();
      return reply({ revision: row?.revision ?? 0 });
    }
    const row = await database().prepare("SELECT payload, revision, mutation_id FROM supervisor_task_lists WHERE owner_id = ?").bind(owner).first<{ payload: string; revision: number; mutation_id: string }>();
    return reply({ tasks: row ? JSON.parse(row.payload) : [], revision: row?.revision ?? 0, mutationId: row?.mutation_id ?? null });
  } catch (error) {
    console.error("Checklist load failed", error);
    return reply({ error: "The shared checklist is unavailable. Please retry." }, 503);
  }
}

export async function PUT(request: Request) {
  try {
    const user = await getChatGPTUser();
    if (!user) return reply({ error: "Sign in to save your checklist." }, 401);
    if (request.headers.get("origin") !== new URL(request.url).origin || !request.headers.get("content-type")?.startsWith("application/json")) return reply({ error: "Invalid request origin." }, 403);
    const raw = await request.text();
    if (raw.length > 2000000) return reply({ error: "Checklist is too large." }, 413);
    let input;
    try { input = JSON.parse(raw); } catch { return reply({ error: "Invalid JSON." }, 400); }
    const { tasks, revision, mutationId } = input;
    if (!validTasks(tasks) || !Number.isSafeInteger(revision) || revision < 0 || typeof mutationId !== "string" || mutationId.length > 100) return reply({ error: "Invalid checklist." }, 400);
    const owner = await ownerFor(user.userId);
    const db = database();
    const result = revision === 0
      ? await db.prepare("INSERT INTO supervisor_task_lists (owner_id, payload, revision, mutation_id, updated_at) VALUES (?, ?, 1, ?, ?) ON CONFLICT(owner_id) DO NOTHING").bind(owner, JSON.stringify(tasks), mutationId, new Date().toISOString()).run()
      : await db.prepare("UPDATE supervisor_task_lists SET payload = ?, revision = revision + 1, mutation_id = ?, updated_at = ? WHERE owner_id = ? AND revision = ?").bind(JSON.stringify(tasks), mutationId, new Date().toISOString(), owner, revision).run();
    if (result.meta.changes) return reply({ revision: revision + 1 });
    const current = await db.prepare("SELECT revision, mutation_id FROM supervisor_task_lists WHERE owner_id = ?").bind(owner).first<{ revision: number; mutation_id: string }>();
    if (current?.mutation_id === mutationId) return reply({ revision: current.revision });
    return reply({ error: "Your checklist changed on another device. The latest shared list will be loaded." }, 409);
  } catch (error) {
    console.error("Checklist save failed", error);
    return reply({ error: "Could not save the checklist. It will retry shortly." }, 503);
  }
}
