import assert from "node:assert/strict";
import { test } from "node:test";
import { readFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import vm from "node:vm";
import ts from "typescript";

test("private board storage, isolated identities, atomic revisions and retry safety", async () => {
  const sqlite = new DatabaseSync(":memory:");
  sqlite.exec(readFileSync(new URL("../drizzle/0000_plain_tenebrous.sql", import.meta.url), "utf8"));
  const db = { prepare(sql) { return { bind(...values) { return {
    async run() { const result = sqlite.prepare(sql).run(...values); return { meta: { changes: Number(result.changes) } }; },
    async first() { return sqlite.prepare(sql).get(...values) || null; },
  }; } }; } };
  function module(path, mocks) {
    const code = ts.transpileModule(readFileSync(new URL(path, import.meta.url), "utf8"), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
    const exports = {};
    vm.runInNewContext(code, { exports, require: (name) => { if (!(name in mocks)) throw new Error(name); return mocks[name]; }, crypto, Response, URL, console });
    return exports;
  }
  const store = module("../db/board-store.ts", { "cloudflare:workers": { env: { DB: db } } });
  let user = { userId: "brendan" };
  const api = module("../app/api/boards/route.ts", { "../../chatgpt-auth": { getChatGPTUser: async () => user }, "../../../db/board-store": store });
  const url = "https://board.test/api/boards?date=2026-09-11";
  const revisionUrl = "https://board.test/api/boards?date=2026-09-11&view=revision";
  const board = { date: "2026-09-11", editors: [], jobs: [], suites: {}, suiteModes: {} };
  const put = (revision, mutationId, origin = "https://board.test") => api.PUT(new Request(url, { method: "PUT", headers: { origin, "Content-Type": "application/json" }, body: JSON.stringify({ board, revision, mutationId }) }));
  assert.equal((await (await api.GET(new Request(url))).json()).revision, 0);
  assert.equal((await (await api.GET(new Request(revisionUrl))).json()).revision, 0);
  assert.equal((await put(0, "first")).status, 200);
  assert.equal((await (await api.GET(new Request(revisionUrl))).json()).revision, 1);
  assert.equal((await put(0, "first")).status, 200);
  assert.equal((await put(0, "stale")).status, 409);
  assert.equal((await put(1, "second")).status, 200);
  assert.equal((await put(1, "other-device")).status, 409);
  assert.equal((await (await api.GET(new Request(url))).json()).revision, 2);
  assert.equal((await put(2, "cross-site", "https://attacker.test")).status, 403);
  user = { userId: "someone-else" };
  assert.equal((await (await api.GET(new Request(url))).json()).revision, 0);
  user = null;
  assert.equal((await api.GET(new Request(url))).status, 401);
  assert.equal((await put(0, "anonymous")).status, 401);
  sqlite.close();
});
