export const editorMatch = `(
  lower(trim(coalesce(json_extract(j.value, '$.completedBy'), ''))) = s.editor
  OR lower(trim(coalesce(json_extract(j.value, '$.biffedBy'), ''))) = s.editor
  OR lower(trim(coalesce(json_extract(j.value, '$.parkedFromEditorName'), ''))) = s.editor
  OR EXISTS (
    SELECT 1 FROM json_each(b.payload, '$.editors') ed
    WHERE lower(trim(json_extract(ed.value, '$.name'))) = s.editor AND (
      json_extract(ed.value, '$.id') IN (json_extract(j.value, '$.editorId'), json_extract(j.value, '$.parkedFromEditorId'))
      OR EXISTS (SELECT 1 FROM json_each(j.value, '$.history') h
        WHERE json_extract(ed.value, '$.id') IN (json_extract(h.value, '$.editorId'), json_extract(h.value, '$.previousEditorId')))
    )
  )
  OR EXISTS (SELECT 1 FROM json_each(j.value, '$.history') h
    WHERE lower(trim(coalesce(json_extract(h.value, '$.editorName'), ''))) = s.editor
      OR lower(trim(coalesce(json_extract(h.value, '$.previousEditorName'), ''))) = s.editor)
)`;

export const suiteMatch = `(
  s.suite IN (json_extract(j.value, '$.suite'), json_extract(j.value, '$.completedSuite'),
    json_extract(j.value, '$.biffedSuite'), json_extract(j.value, '$.parkedFromSuite'))
  OR EXISTS (SELECT 1 FROM json_each(j.value, '$.history') h
    WHERE s.suite IN (json_extract(h.value, '$.suite'), json_extract(h.value, '$.previousSuite')))
)`;

const editorIdMatches = (id: string) => `EXISTS (SELECT 1 FROM json_each(b.payload, '$.editors') paired_editor
  WHERE json_extract(paired_editor.value, '$.id') = ${id}
    AND lower(trim(json_extract(paired_editor.value, '$.name'))) = s.editor)`;

const recordedPair = (suiteField: string, nameField: string, idField: string) => `(
  json_extract(j.value, '$.${suiteField}') = s.suite AND (
    lower(trim(coalesce(json_extract(j.value, '$.${nameField}'), ''))) = s.editor
    OR ${editorIdMatches(`json_extract(j.value, '$.${idField}')`)}))`;

export const editorSuiteMatch = `(
  (json_extract(j.value, '$.suite') = s.suite AND ${editorIdMatches("json_extract(j.value, '$.editorId')")})
  OR ${recordedPair('completedSuite', 'completedBy', 'editorId')}
  OR ${recordedPair('biffedSuite', 'biffedBy', 'editorId')}
  OR ${recordedPair('parkedFromSuite', 'parkedFromEditorName', 'parkedFromEditorId')}
  OR EXISTS (SELECT 1 FROM json_each(j.value, '$.history') paired_event WHERE (
    json_extract(paired_event.value, '$.suite') = s.suite AND (
      lower(trim(coalesce(json_extract(paired_event.value, '$.editorName'), ''))) = s.editor
      OR ${editorIdMatches("json_extract(paired_event.value, '$.editorId')")}
      OR (json_extract(paired_event.value, '$.type') = 'unassigned' AND (
        lower(trim(coalesce(json_extract(paired_event.value, '$.previousEditorName'), ''))) = s.editor
        OR ${editorIdMatches("json_extract(paired_event.value, '$.previousEditorId')")})
      )
    )) OR (json_extract(paired_event.value, '$.previousSuite') = s.suite AND (
      lower(trim(coalesce(json_extract(paired_event.value, '$.previousEditorName'), ''))) = s.editor
      OR ${editorIdMatches("json_extract(paired_event.value, '$.previousEditorId')")}))
  )
)`;

export const searchSql = `WITH s AS (SELECT ? AS owner, ? AS query, ? AS editor, ? AS suite)
  SELECT b.date, j.value AS job_json, json_extract(b.payload, '$.editors') AS editors_json
  FROM boards b, json_each(b.payload, '$.jobs') j, s
  WHERE b.owner_id = s.owner
    AND (s.query = '' OR instr(lower(json_extract(j.value, '$.title')), lower(s.query)) > 0)
    AND (s.editor = '' OR ${editorMatch})
    AND (s.suite = 0 OR ${suiteMatch})
    AND (s.editor = '' OR s.suite = 0 OR ${editorSuiteMatch})
  ORDER BY b.date DESC, CAST(j.key AS INTEGER) DESC LIMIT ? OFFSET ?`;

export const editorOptionsPageSql = `SELECT date, payload FROM boards
  WHERE owner_id = ? AND date > ? ORDER BY date LIMIT 5`;

export function collectEditorOptions(board: unknown, names: Map<string, string>) {
  if (!board || typeof board !== "object") return;
  const data = board as Record<string, unknown>;
  const add = (value: unknown) => {
    if (typeof value !== "string" || !value.trim()) return;
    const name = value.trim();
    // Match SQLite lower(), which folds ASCII letters in the search filters.
    const key = name.replace(/[A-Z]/g, (letter) => letter.toLowerCase());
    if (key !== "unassigned" && key !== "unassigned editor" && !names.has(key)) names.set(key, name);
  };
  if (Array.isArray(data.editors)) data.editors.forEach((editor) => { if (editor && typeof editor === "object") add(editor.name); });
  if (Array.isArray(data.jobs)) data.jobs.forEach((job) => {
    if (!job || typeof job !== "object") return;
    add(job.completedBy); add(job.biffedBy); add(job.parkedFromEditorName);
    if (Array.isArray(job.history)) job.history.forEach((event: Record<string, unknown> | null) => {
      if (!event || typeof event !== "object") return;
      add(event.editorName); add(event.previousEditorName);
    });
  });
}

export type EditorSuiteOption = { key: string; name: string; suites: Set<number> };

export function collectEditorSuiteOptions(board: unknown, options: Map<string, EditorSuiteOption>) {
  if (!board || typeof board !== 'object') return;
  const data = board as Record<string, unknown>;
  const names = new Map<string, string>();
  collectEditorOptions(board, names);
  for (const [key, name] of names) if (!options.has(key)) options.set(key, { key, name, suites: new Set() });
  const roster = Array.isArray(data.editors) ? data.editors.filter((editor) => editor && typeof editor === 'object') : [];
  const nameFor = (id: unknown) => roster.find((editor) => editor.id === id)?.name;
  const link = (name: unknown, suiteValue: unknown) => {
    if (typeof name !== 'string' || !name.trim()) return;
    const suite = Number(suiteValue);
    if (!Number.isInteger(suite) || suite < 1 || suite > 11) return;
    const key = name.trim().replace(/[A-Z]/g, (letter) => letter.toLowerCase());
    if (key === 'unassigned' || key === 'unassigned editor') return;
    if (!options.has(key)) options.set(key, { key, name: name.trim(), suites: new Set() });
    options.get(key)!.suites.add(suite);
  };
  if (data.suites && typeof data.suites === 'object') {
    for (const [suite, editorId] of Object.entries(data.suites)) link(nameFor(editorId), suite);
  }
  if (!Array.isArray(data.jobs)) return;
  for (const job of data.jobs) {
    if (!job || typeof job !== 'object') continue;
    link(nameFor(job.editorId), job.suite);
    link(job.completedBy || nameFor(job.editorId), job.completedSuite);
    link(job.biffedBy || nameFor(job.editorId), job.biffedSuite);
    link(job.parkedFromEditorName || nameFor(job.parkedFromEditorId), job.parkedFromSuite);
    if (!Array.isArray(job.history)) continue;
    for (const event of job.history) {
      if (!event || typeof event !== 'object') continue;
      link(event.editorName || nameFor(event.editorId), event.suite);
      link(event.previousEditorName || nameFor(event.previousEditorId), event.previousSuite);
      if (event.type === 'unassigned') link(event.previousEditorName || nameFor(event.previousEditorId), event.suite);
    }
  }
}
