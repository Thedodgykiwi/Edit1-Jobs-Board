// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, text, integer, primaryKey } from "drizzle-orm/sqlite-core";

export const principals = sqliteTable("principals", {
  id: text("id").primaryKey(),
  subject: text("subject").notNull().unique(),
});

export const boards = sqliteTable("boards", {
  ownerId: text("owner_id").notNull().references(() => principals.id),
  date: text("date").notNull(),
  payload: text("payload").notNull(),
  revision: integer("revision").notNull(),
  mutationId: text("mutation_id").notNull(),
  updatedAt: text("updated_at").notNull(),
}, (table) => [primaryKey({ columns: [table.ownerId, table.date] })]);

export const supervisorTaskLists = sqliteTable("supervisor_task_lists", {
  ownerId: text("owner_id").primaryKey().references(() => principals.id),
  payload: text("payload").notNull(),
  revision: integer("revision").notNull(),
  mutationId: text("mutation_id").notNull(),
  updatedAt: text("updated_at").notNull(),
});
