import { env } from "cloudflare:workers";

export function database() {
  if (!env.DB) throw new Error("Database unavailable");
  return env.DB;
}

export async function ownerFor(subject: string) {
  const db = database();
  await db.prepare("INSERT INTO principals (id, subject) VALUES (?, ?) ON CONFLICT(subject) DO NOTHING")
    .bind(crypto.randomUUID(), `chatgpt:${subject}`).run();
  const owner = await db.prepare("SELECT id FROM principals WHERE subject = ?")
    .bind(`chatgpt:${subject}`).first<{ id: string }>();
  if (!owner) throw new Error("Identity unavailable");
  return owner.id;
}
