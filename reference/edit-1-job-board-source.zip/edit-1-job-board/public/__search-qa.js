const qaRow = {"date": "2026-10-01", "editors": [{"id": "alice", "name": "Alice Editor", "initials": "AE"}], "job": {"id": "search-qa", "title": "Climate report", "status": "completed", "workType": "TV", "editorId": "alice", "suite": 2, "completedBy": "Alice Editor", "completedSuite": 2, "note": "A saved job for preview checks.", "history": [{"type": "created", "at": "2026-10-01T08:00:00Z"}, {"type": "started", "at": "2026-10-01T08:05:00Z", "editorId": "alice", "suite": 2}, {"type": "completed", "at": "2026-10-01T08:30:00Z", "editorId": "alice", "suite": 2}]}};
window.fetch = async (url, options = {}) => {
 const target = new URL(url, location.origin);
 let data;
 if (target.pathname === '/api/job-search') {
  if(target.searchParams.get('facets')) data={editors:[{key:'alice editor',name:'Alice Editor'}]};
  else {const match=qaRow.job.title.toLowerCase().includes((target.searchParams.get('q')||'').toLowerCase()) && (!target.searchParams.get('suite')||target.searchParams.get('suite')==='2');data={results:match?[qaRow]:[],hasMore:false,nextOffset:match?1:0};}
 } else if (target.pathname === '/api/boards') data={board:null,revision:0};
 else if(target.pathname === '/api/tasks') data={tasks:[],revision:0};
 else throw new Error('Unexpected QA request');
 return new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});
};