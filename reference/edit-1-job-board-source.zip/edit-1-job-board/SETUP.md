# Edit 1 Job Board — local setup

This export contains the source for Sites version 136 (commit `444cedb8248fa15db95d96df7d1c5cd707ac5f6b`). It includes the original README and migration notes alongside this project-specific quick start.

## Run locally

1. Install Node.js 22.13 or newer and pnpm 11.25.0. If you have Corepack, run `corepack enable` to use the pnpm version pinned in `package.json`.
2. Extract the ZIP, open a terminal in the `edit-1-job-board` folder, then install dependencies and build:

   ```sh
   pnpm install --frozen-lockfile
   pnpm run build
   ```

3. Apply the included migrations **once**, in order, to a fresh local Cloudflare D1 database. Run both commands from the project root. The `--local` flag and persistence path keep this data on your machine.

   ```sh
   node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_plain_tenebrous.sql
   node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_cool_microchip.sql
   ```

4. Run `pnpm run dev`, then open [http://localhost:5173/signin-with-chatgpt?return_to=/](http://localhost:5173/signin-with-chatgpt?return_to=/). This signs you in as a mock user on the local development server. No real ChatGPT account or credentials are needed for this local step. Start with the development server; the built Worker preview does not simulate sign-in.

## Project layout

| Path | Contents |
| --- | --- |
| `board/` | Main job board HTML |
| `public/` | Browser JavaScript, styles, SVG assets and search QA page |
| `app/` | Server routes for the board, tasks and job search, plus authentication helpers |
| `components/`, `hooks/`, `lib/` | Shared interface components and utilities |
| `db/`, `drizzle/` | D1 data layer, schema and SQL migrations |
| `build/`, `scripts/`, `vendor/` | Build tooling and vendored styles |
| `tests/` | API tests; see `MIGRATION.md` |
| `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml` | Dependency and package manager configuration |

## Hosted services

The live site gets visitor identity and its production D1 binding from Sites. This ZIP has the database schema and migrations, but no live board records, credentials or installed dependencies. The included hosting manifest identifies the existing Sites project; keep this export local unless you deliberately configure a separate deployment target and its own database and authentication.
